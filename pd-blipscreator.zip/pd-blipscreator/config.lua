Config = {}

Config.Debug = false
Config.BlipUpdateInterval = 1000

Config.Framework = 'auto' -- 'auto', 'qb-core', 'esx'
Config.QBCore = {
    AdminGroups = {
        'admin',
        'superadmin',
        'owner'
    }
}
Config.ESX = {
    AdminGroups = {
        'admin',
        'superadmin',
        'owner'
    }
}

Config.Blips = {
        {
        name = "Coffee Bar",
        sprite = 93,
        color = 81,
        coords = vector3(281.5838, -968.1395, 29.4217),
        scale = 0.8,
        display = 4,
        shortRange = false
    },
        {
        name = "Blip2",
        sprite = 102,
        color = 81,
        coords = vector3(837.2241, -113.4564, 79.7747),
        scale = 0.9,
        display = 4,
        shortRange = false
    },
}

Config.AdminCommands = {
    "addblip",
    "removeblip",
    "reloadblips"
}

Config.AdminGroups = {
    "admin",
    "superadmin",
    "owner"
}
