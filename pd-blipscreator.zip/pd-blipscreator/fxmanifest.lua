fx_version 'cerulean'
game 'gta5'

author 'print-development'
description 'A basic script to create blips in your 5M server!'
version '1.0.0'

shared_scripts {
    'config.lua'
}

client_scripts {
    'client/main.lua'
}

server_scripts {
    'server/main.lua'
}
