-- pd-blipscreator CREATOR - CLIENT SIDE
-- Автор: printzzzz.t
-- Поддържа QB-Core и ESX

local blips = {}
local isInitialized = false
local Framework = nil
local FrameworkType = nil

-- Framework detection and initialization
local function InitializeFramework()
    if Config.Framework == 'auto' then
        -- Try QB-Core first
        if GetResourceState('qb-core') == 'started' then
            FrameworkType = 'qb-core'
            Framework = exports['qb-core']:GetCoreObject()
            if Config.Debug then
                print("^2[pd-blipscreator]^7 QB-Core detected and initialized")
            end
            return true
        -- Try ESX
        elseif GetResourceState('es_extended') == 'started' then
            FrameworkType = 'esx'
            Framework = exports['es_extended']:getSharedObject()
            if Config.Debug then
                print("^2[pd-blipscreator]^7 ESX detected and initialized")
            end
            return true
        else
            if Config.Debug then
                print("^1[pd-blipscreator ERROR]^7 No supported framework detected!")
            end
            return false
        end
    else
        -- Manual framework selection
        if Config.Framework == 'qb-core' and GetResourceState('qb-core') == 'started' then
            FrameworkType = 'qb-core'
            Framework = exports['qb-core']:GetCoreObject()
            return true
        elseif Config.Framework == 'esx' and GetResourceState('es_extended') == 'started' then
            FrameworkType = 'esx'
            Framework = exports['es_extended']:getSharedObject()
            return true
        else
            if Config.Debug then
                print("^1[pd-blipscreator ERROR]^7 Specified framework not found!")
            end
            return false
        end
    end
end

-- Функция за създаване на блип
local function CreateBlip(blipData)
    if blipData and blipData.coords then
        local blip = AddBlipForCoord(blipData.coords.x, blipData.coords.y, blipData.coords.z)
        
        SetBlipSprite(blip, blipData.sprite or 1)
        SetBlipDisplay(blip, blipData.display or 4)
        SetBlipScale(blip, blipData.scale or 0.8)
        SetBlipColour(blip, blipData.color or 0)
        SetBlipAsShortRange(blip, blipData.shortRange or true)
        
        BeginTextCommandSetBlipName("STRING")
        AddTextComponentString(blipData.name or "Unknown")
        EndTextCommandSetBlipName(blip)
        
        return blip
    end
    return nil
end

-- Функция за изтриване на всички блипове
local function RemoveAllBlips()
    for _, blip in pairs(blips) do
        if DoesBlipExist(blip) then
            RemoveBlip(blip)
        end
    end
    blips = {}
end

-- Функция за инициализиране на всички блипове
local function InitializeBlips()
    if isInitialized then
        RemoveAllBlips()
    end
    
    for _, blipData in pairs(Config.Blips) do
        local blip = CreateBlip(blipData)
        if blip then
            table.insert(blips, blip)
            if Config.Debug then
                print("^2[pd-blipscreator]^7 Създаден блип: " .. blipData.name)
            end
        end
    end
    
    isInitialized = true
    if Config.Debug then
        print("^2[pd-blipscreator]^7 Инициализирани " .. #blips .. " блипа")
    end
end

-- Функция за добавяне на нов блип
local function AddCustomBlip(name, sprite, color, coords, scale, display, shortRange)
    local newBlipData = {
        name = name or "Custom Blip",
        sprite = sprite or 1,
        color = color or 0,
        coords = coords or vector3(0, 0, 0),
        scale = scale or 0.8,
        display = display or 4,
        shortRange = shortRange or true
    }
    
    local blip = CreateBlip(newBlipData)
    if blip then
        table.insert(blips, blip)
        table.insert(Config.Blips, newBlipData)
        if Config.Debug then
            print("^2[pd-blipscreator]^7 Добавен нов блип: " .. name)
        end
        return true
    end
    return false
end

-- Функция за премахване на блип по име
local function RemoveBlipByName(name)
    for i, blipData in ipairs(Config.Blips) do
        if blipData.name == name then
            if blips[i] and DoesBlipExist(blips[i]) then
                RemoveBlip(blips[i])
                table.remove(blips, i)
            end
            table.remove(Config.Blips, i)
            if Config.Debug then
                print("^2[pd-blipscreator]^7 Премахнат блип: " .. name)
            end
            return true
        end
    end
    return false
end

-- Функция за проверка дали играчът е администратор
local function IsPlayerAdmin()
    if not Framework then return false end
    
    if FrameworkType == 'qb-core' then
        local Player = Framework.Functions.GetPlayerData()
        if Player and Player.PlayerData then
            for _, group in pairs(Config.QBCore.AdminGroups) do
                if Player.PlayerData.permission == group then
                    return true
                end
            end
        end
    elseif FrameworkType == 'esx' then
        local Player = Framework.GetPlayerData()
        if Player and Player.group then
            for _, group in pairs(Config.ESX.AdminGroups) do
                if Player.group == group then
                    return true
                end
            end
        end
    end
    
    return false
end

-- Команди за администратори
RegisterCommand("addblip", function(source, args, rawCommand)
    if not IsPlayerAdmin() then
        TriggerEvent("chat:addMessage", {
            color = {255, 0, 0},
            multiline = true,
            args = {"pd-blipscreator", "Нямате права за тази команда!"}
        })
        return
    end
    
    if #args < 4 then
        TriggerEvent("chat:addMessage", {
            color = {255, 255, 0},
            multiline = true,
            args = {"pd-blipscreator", "Използване: /addblip [име] [sprite] [color] [x] [y] [z] [scale] [display]"}
        })
        return
    end
    
    local name = args[1]
    local sprite = tonumber(args[2])
    local color = tonumber(args[3])
    local x = tonumber(args[4])
    local y = tonumber(args[5])
    local z = tonumber(args[6]) or 0
    local scale = tonumber(args[7]) or 0.8
    local display = tonumber(args[8]) or 4
    
    local coords = vector3(x, y, z)
    
    if AddCustomBlip(name, sprite, color, coords, scale, display, true) then
        TriggerEvent("chat:addMessage", {
            color = {0, 255, 0},
            multiline = true,
            args = {"pd-blipscreator", "Блипът '" .. name .. "' е добавен успешно!"}
        })
    else
        TriggerEvent("chat:addMessage", {
            color = {255, 0, 0},
            multiline = true,
            args = {"pd-blipscreator", "Грешка при добавянето на блипа!"}
        })
    end
end, false)

RegisterCommand("removeblip", function(source, args, rawCommand)
    if not IsPlayerAdmin() then
        TriggerEvent("chat:addMessage", {
            color = {255, 0, 0},
            multiline = true,
            args = {"pd-blipscreator", "Нямате права за тази команда!"}
        })
        return
    end
    
    if #args < 1 then
        TriggerEvent("chat:addMessage", {
            color = {255, 255, 0},
            multiline = true,
            args = {"pd-blipscreator", "Използване: /removeblip [име]"}
        })
        return
    end
    
    local name = args[1]
    
    if RemoveBlipByName(name) then
        TriggerEvent("chat:addMessage", {
            color = {0, 255, 0},
            multiline = true,
            args = {"pd-blipscreator", "Блипът '" .. name .. "' е премахнат успешно!"}
        })
    else
        TriggerEvent("chat:addMessage", {
            color = {255, 0, 0},
            multiline = true,
            args = {"pd-blipscreator", "Блипът '" .. name .. "' не е намерен!"}
        })
    end
end, false)

RegisterCommand("reloadblips", function(source, args, rawCommand)
    if not IsPlayerAdmin() then
        TriggerEvent("chat:addMessage", {
            color = {255, 0, 0},
            multiline = true,
            args = {"pd-blipscreator", "Нямате права за тази команда!"}
        })
        return
    end
    
    InitializeBlips()
    TriggerEvent("chat:addMessage", {
        color = {0, 255, 0},
        multiline = true,
        args = {"pd-blipscreator", "Всички блипове са презаредени!"}
    })
end, false)

-- Събития
RegisterNetEvent("pd-blips:reload")
AddEventHandler("pd-blips:reload", function()
    InitializeBlips()
end)

RegisterNetEvent("pd-blips:add")
AddEventHandler("pd-blips:add", function(blipData)
    AddCustomBlip(blipData.name, blipData.sprite, blipData.color, blipData.coords, blipData.scale, blipData.display, blipData.shortRange)
end)

RegisterNetEvent("pd-blips:remove")
AddEventHandler("pd-blips:remove", function(name)
    RemoveBlipByName(name)
end)

-- Инициализация при стартиране
Citizen.CreateThread(function()
    -- Wait for frameworks to load
    Citizen.Wait(3000)
    
    -- Initialize framework
    if not InitializeFramework() then
        if Config.Debug then
            print("^1[pd-blipscreator ERROR]^7 Failed to initialize framework")
        end
        return
    end
    
    -- Initialize blips
    InitializeBlips()
    
    if Config.Debug then
        print("^2[pd-blipscreator]^7 Клиентската част е заредена успешно!")
        print("^2[pd-blipscreator]^7 Framework: " .. FrameworkType)
    end
end)

-- Основен цикъл за обновяване
Citizen.CreateThread(function()
    while true do
        Citizen.Wait(Config.BlipUpdateInterval)
        
        -- Проверка за валидност на блиповете
        for i, blip in ipairs(blips) do
            if not DoesBlipExist(blip) then
                table.remove(blips, i)
                if Config.Debug then
                    print("^3[pd-blipscreator]^7 Премахнат невалиден блип")
                end
            end
        end
    end
end)
