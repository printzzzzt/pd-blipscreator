-- PD BLIPS CREATOR - SERVER SIDE
-- Автор: printzzzz.t
-- Поддържа QB-Core и ESX

local Framework = nil
local FrameworkType = nil

-- Framework detection and initialization
local function InitializeFramework()
    if Config.Framework == 'auto' then
        -- Try QB-Core first
        if GetResourceState('qb-core') == 'started' then
            FrameworkType = 'qb-core'
            Framework = exports['qb-core']:GetCoreObject()
            if Config.Debug then
                print("^2[pd-blipscreator]^7 QB-Core detected and initialized")
            end
            return true
        -- Try ESX
        elseif GetResourceState('es_extended') == 'started' then
            FrameworkType = 'esx'
            Framework = exports['es_extended']:getSharedObject()
            if Config.Debug then
                print("^2[pd-blipscreator]^7 ESX detected and initialized")
            end
            return true
        else
            if Config.Debug then
                print("^1[pd-blipscreator ERROR]^7 No supported framework detected!")
            end
            return false
        end
    else
        -- Manual framework selection
        if Config.Framework == 'qb-core' and GetResourceState('qb-core') == 'started' then
            FrameworkType = 'qb-core'
            Framework = exports['qb-core']:GetCoreObject()
            return true
        elseif Config.Framework == 'esx' and GetResourceState('es_extended') == 'started' then
            FrameworkType = 'esx'
            Framework = exports['es_extended']:getSharedObject()
            return true
        else
            if Config.Debug then
                print("^1[pd-blipscreator ERROR]^7 Specified framework not found!")
            end
            return false
        end
    end
end

-- Функция за проверка дали играчът е администратор
local function IsPlayerAdmin(source)
    if not Framework then return false end
    
    if FrameworkType == 'qb-core' then
        local Player = Framework.Functions.GetPlayer(source)
        if Player then
            for _, group in pairs(Config.QBCore.AdminGroups) do
                if Player.PlayerData.permission == group then
                    return true
                end
            end
        end
    elseif FrameworkType == 'esx' then
        local xPlayer = Framework.GetPlayerFromId(source)
        if xPlayer then
            local playerGroup = xPlayer.getGroup()
            for _, group in pairs(Config.ESX.AdminGroups) do
                if playerGroup == group then
                    return true
                end
            end
        end
    end
    
    return false
end

-- Функция за логване на действия
local function LogAction(source, action, details)
    if not Framework then return end
    
    if FrameworkType == 'qb-core' then
        local Player = Framework.Functions.GetPlayer(source)
        if Player then
            local playerName = Player.PlayerData.charinfo.firstname .. " " .. Player.PlayerData.charinfo.lastname
            local playerIdentifier = Player.PlayerData.citizenid
            
            print("^3[pd-blipscreator LOG]^7 " .. playerName .. " (" .. playerIdentifier .. ") " .. action .. ": " .. (details or ""))
        end
    elseif FrameworkType == 'esx' then
        local xPlayer = Framework.GetPlayerFromId(source)
        if xPlayer then
            local playerName = xPlayer.getName()
            local playerIdentifier = xPlayer.getIdentifier()
            
            print("^3[pd-blipscreator LOG]^7 " .. playerName .. " (" .. playerIdentifier .. ") " .. action .. ": " .. (details or ""))
        end
    end
    
    -- Тук можете да добавите логване в база данни или файл
end

-- Сървърни команди за администратори
RegisterCommand("s_addblip", function(source, args, rawCommand)
    if not IsPlayerAdmin(source) then
        TriggerClientEvent("chat:addMessage", source, {
            color = {255, 0, 0},
            multiline = true,
            args = {"pd-blipscreator", "Нямате права за тази команда!"}
        })
        return
    end
    
    if #args < 4 then
        TriggerClientEvent("chat:addMessage", source, {
            color = {255, 255, 0},
            multiline = true,
            args = {"pd-blipscreator", "Използване: /s_addblip [име] [sprite] [color] [x] [y] [z] [scale] [display]"}
        })
        return
    end
    
    local name = args[1]
    local sprite = tonumber(args[2])
    local color = tonumber(args[3])
    local x = tonumber(args[4])
    local y = tonumber(args[5])
    local z = tonumber(args[6]) or 0
    local scale = tonumber(args[7]) or 0.8
    local display = tonumber(args[8]) or 4
    
    local coords = vector3(x, y, z)
    
    -- Създаване на нов блип данни
    local newBlipData = {
        name = name,
        sprite = sprite,
        color = color,
        coords = coords,
        scale = scale,
        display = display,
        shortRange = true
    }
    
    -- Добавяне в конфигурацията
    table.insert(Config.Blips, newBlipData)
    
    -- Изпращане към всички клиенти
    TriggerClientEvent("pd-blips:add", -1, newBlipData)
    
    LogAction(source, "добави блип", name)
    
    TriggerClientEvent("chat:addMessage", source, {
        color = {0, 255, 0},
        multiline = true,
        args = {"pd-blipscreator", "Блипът '" .. name .. "' е добавен успешно за всички играчи!"}
    })
end, false)

RegisterCommand("s_removeblip", function(source, args, rawCommand)
    if not IsPlayerAdmin(source) then
        TriggerClientEvent("chat:addMessage", source, {
            color = {255, 0, 0},
            multiline = true,
            args = {"pd-blipscreator", "Нямате права за тази команда!"}
        })
        return
    end
    
    if #args < 1 then
        TriggerClientEvent("chat:addMessage", source, {
            color = {255, 255, 0},
            multiline = true,
            args = {"pd-blipscreator", "Използване: /s_removeblip [име]"}
        })
        return
    end
    
    local name = args[1]
    local found = false
    
    -- Премахване от конфигурацията
    for i, blipData in ipairs(Config.Blips) do
        if blipData.name == name then
            table.remove(Config.Blips, i)
            found = true
            break
        end
    end
    
    if found then
        -- Изпращане към всички клиенти
        TriggerClientEvent("pd-blips:remove", -1, name)
        
        LogAction(source, "премахна блип", name)
        
        TriggerClientEvent("chat:addMessage", source, {
            color = {0, 255, 0},
            multiline = true,
            args = {"pd-blipscreator", "Блипът '" .. name .. "' е премахнат успешно за всички играчи!"}
        })
    else
        TriggerClientEvent("chat:addMessage", source, {
            color = {255, 0, 0},
            multiline = true,
            args = {"pd-blipscreator", "Блипът '" .. name .. "' не е намерен!"}
        })
    end
end, false)

RegisterCommand("s_reloadblips", function(source, args, rawCommand)
    if not IsPlayerAdmin(source) then
        TriggerClientEvent("chat:addMessage", source, {
            color = {255, 0, 0},
            multiline = true,
            args = {"pd-blipscreator", "Нямате права за тази команда!"}
        })
        return
    end
    
    -- Презареждане на блиповете за всички клиенти
    TriggerClientEvent("pd-blips:reload", -1)
    
    LogAction(source, "презареди блипове", "всички блипове")
    
    TriggerClientEvent("chat:addMessage", source, {
        color = {0, 255, 0},
        multiline = true,
        args = {"pd-blipscreator", "Всички блипове са презаредени за всички играчи!"}
    })
end, false)

-- Команда за показване на списък с блипове
RegisterCommand("listblips", function(source, args, rawCommand)
    if not IsPlayerAdmin(source) then
        TriggerClientEvent("chat:addMessage", source, {
            color = {255, 0, 0},
            multiline = true,
            args = {"pd-blipscreator", "Нямате права за тази команда!"}
        })
        return
    end
    
    local blipList = "Списък с блипове:\n"
    for i, blipData in ipairs(Config.Blips) do
        blipList = blipList .. i .. ". " .. blipData.name .. " (ID: " .. blipData.sprite .. ")\n"
    end
    
    TriggerClientEvent("chat:addMessage", source, {
        color = {0, 255, 255},
        multiline = true,
        args = {"pd-blipscreator", blipList}
    })
end, false)

-- Команда за запазване на блиповете в файл
RegisterCommand("saveblips", function(source, args, rawCommand)
    if not IsPlayerAdmin(source) then
        TriggerClientEvent("chat:addMessage", source, {
            color = {255, 0, 0},
            multiline = true,
            args = {"pd-blipscreator", "Нямате права за тази команда!"}
        })
        return
    end
    
    -- Тук можете да добавите логика за запазване в база данни или файл
    LogAction(source, "запази блипове", "всички блипове са запазени")
    
    TriggerClientEvent("chat:addMessage", source, {
        color = {0, 255, 0},
        multiline = true,
        args = {"pd-blipscreator", "Всички блипове са запазени успешно!"}
    })
end, false)

-- Събития за синхронизация между клиенти
RegisterNetEvent("pd-blips:requestSync")
AddEventHandler("pd-blips:requestSync", function()
    local source = source
    
    if IsPlayerAdmin(source) then
        -- Изпращане на всички блипове към клиента
        for _, blipData in pairs(Config.Blips) do
            TriggerClientEvent("pd-blips:add", source, blipData)
        end
        
        if Config.Debug then
            print("^2[pd-blipscreator]^7 Синхронизирани " .. #Config.Blips .. " блипа с клиент " .. source)
        end
    end
end)

-- Събитие за добавяне на блип от клиент
RegisterNetEvent("pd-blips:addFromClient")
AddEventHandler("pd-blips:addFromClient", function(blipData)
    local source = source
    
    if IsPlayerAdmin(source) and blipData then
        -- Добавяне в конфигурацията
        table.insert(Config.Blips, blipData)
        
        -- Изпращане към всички клиенти
        TriggerClientEvent("pd-blips:add", -1, blipData)
        
        LogAction(source, "добави блип от клиент", blipData.name)
        
        if Config.Debug then
            print("^2[pd-blipscreator]^7 Добавен блип от клиент: " .. blipData.name)
        end
    end
end)

-- Събитие за премахване на блип от клиент
RegisterNetEvent("pd-blips:removeFromClient")
AddEventHandler("pd-blips:removeFromClient", function(blipName)
    local source = source
    
    if IsPlayerAdmin(source) and blipName then
        local found = false
        
        -- Премахване от конфигурацията
        for i, blipData in ipairs(Config.Blips) do
            if blipData.name == blipName then
                table.remove(Config.Blips, i)
                found = true
                break
            end
        end
        
        if found then
            -- Изпращане към всички клиенти
            TriggerClientEvent("pd-blips:remove", -1, blipName)
            
            LogAction(source, "премахна блип от клиент", blipName)
            
            if Config.Debug then
                print("^2[pd-blipscreator]^7 Премахнат блип от клиент: " .. blipName)
            end
        end
    end
end)

-- Инициализация при стартиране на сървъра
AddEventHandler("onResourceStart", function(resourceName)
    if GetCurrentResourceName() == resourceName then
        -- Initialize framework
        if not InitializeFramework() then
            if Config.Debug then
                print("^1[pd-blipscreator ERROR]^7 Failed to initialize framework")
            end
            return
        end
        
        if Config.Debug then
            print("^2[pd-blipscreator]^7 Сървърната част е заредена успешно!")
            print("^2[pd-blipscreator]^7 Framework: " .. FrameworkType)
            print("^2[pd-blipscreator]^7 Заредени " .. #Config.Blips .. " блипа")
        end
    end
end)

-- Проверка за валидност на конфигурацията
Citizen.CreateThread(function()
    Citizen.Wait(2000)
    
    if not Config.Blips or #Config.Blips == 0 then
        print("^1[pd-blipscreator ERROR]^7 Няма намерени блипове в конфигурацията!")
        return
    end
    
    if Config.Debug then
        print("^2[pd-blipscreator]^7 Конфигурацията е валидна")
        for i, blipData in ipairs(Config.Blips) do
            print("^3[pd-blipscreator]^7 Блип " .. i .. ": " .. blipData.name .. " на координати " .. blipData.coords.x .. ", " .. blipData.coords.y .. ", " .. blipData.coords.z)
        end
    end
end)
